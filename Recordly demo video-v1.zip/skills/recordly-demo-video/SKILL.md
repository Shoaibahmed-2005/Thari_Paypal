---
name: "recordly-demo-video"
description: "Turn a raw screen recording into a polished Recordly-style hackathon demo video — auto zoom in/out, pans, click ripples, speed-ups, callouts, backgrounds, intro/outro, MP4/GIF."
---

# Recordly-style demo video editor

Recreates what the open-source Recordly app (recordly.dev) does — Apple-style eased auto-zoom on activity, smooth pans between zooms, zoom motion blur, click effects, speed regions, trims, annotations, wallpaper/gradient backgrounds with padding, rounded corners and drop shadow, MP4/GIF export — on any uploaded screen recording, using ffmpeg + OpenCV. Built for hackathon demo submissions (Devpost, Unstop, etc.).

## When the user records with Recordly itself
If they have the Recordly app, recommend recording there (it captures real cursor telemetry, so auto-zoom is more precise). This skill covers everything else: a plain OBS / QuickTime / Win+G / phone recording uploaded to chat.

## Workflow (plan first, then render)

1. **Set up.** Write the script at the end of this file to `recordly_edit.py` in the working dir. Check `ffmpeg`, `python3 -c "import cv2, numpy, PIL"`; `pip install opencv-python-headless pillow numpy --break-system-packages` if missing.
2. **Look at the video.** `ffprobe` it, then `python3 recordly_edit.py sheet INPUT.mp4 -o sheet.png --every 2` and Read `sheet.png`. Each tile is timestamped with a yellow 10% grid, so normalized x/y can be read directly (x=0.3 is the 3rd vertical line). For long videos use `--every 4`, or multiple sheets on sub-ranges (trim with ffmpeg first).
3. **Auto-analyze.** `python3 recordly_edit.py analyze INPUT.mp4 -o plan.json` → suggests zooms (local activity: typing, clicks, small UI changes), speed-ups (idle ≥3 s at 4×), and lists `scene_changes` (full-page changes/scrolls — never zoom on these).
4. **Edit the plan like a director** (this is the real work — don't ship raw suggestions):
   - Keep 3–8 zooms per minute. Each zoom ≥ 1.5 s hold. Scale 1.6–2.2 for forms/buttons, 2.5 max for small text. Remove zooms on scrolls/page loads.
   - Zoom on the *payoff*: the input being typed, the button clicked, the AI result appearing.
   - Zooms whose gap is < `merge_gap` (1.2 s) pan directly without zooming out — use this to follow a flow across the screen.
   - Speed up loading spinners, long typing, waiting for API/LLM responses (rate 3–8). Cut dead air entirely with `cuts`.
   - Add `clicks` at key clicks (read time/position from sheets), `annotations` naming each feature ("① Upload a contract", "② AI flags risky clauses"), `intro` (project name + one-line pitch) and `outro` (repo / live link / team).
   - Hackathon length targets: Devpost usually ≤ 3 min (aim 1:30–2:30), first 10 s must show the product.
5. **Preview** (half-res, 30 fps, fast): `python3 recordly_edit.py render INPUT.mp4 plan.json -o preview.mp4 --preview`. Extract frames at each zoom midpoint and transition (`ffmpeg -ss T -i preview.mp4 -frames:v 1 f.png`), Read them, fix framing (target off-center? zoom too tight?), repeat.
6. **Final render:** `python3 recordly_edit.py render INPUT.mp4 plan.json -o demo.mp4 [--gif demo.gif]`. Verify duration + audio with ffprobe, spot-check frames, then send with SendUserFile. Also send `plan.json` so the user can tweak and re-render.

Render speed: about 3 s of render per 1 s of output at 1080p30 in the cloud box (preview is ~4× faster); 60 fps doubles it. Use fps 30 unless asked for 60. For long videos, run the render in the background.

## Plan reference (`plan.json`)
Times are SOURCE seconds; x/y normalized to the source frame (0–1, top-left origin). Omitted keys use defaults.

```json
{
  "output": {"width": 1920, "height": 1080, "fps": 30, "crf": 18},
  "trim":   {"start": 0, "end": null},
  "cuts":   [{"start": 41.0, "end": 47.5}],
  "speed":  [{"start": 12.0, "end": 20.0, "rate": 4.0}],
  "zoom":   {"ramp": 0.7, "merge_gap": 1.2, "motion_blur": true},
  "zooms":  [{"start": 3.0, "end": 7.5, "x": 0.32, "y": 0.41, "scale": 2.0}],
  "clicks": [{"t": 4.2, "x": 0.33, "y": 0.42}],
  "annotations": [{"text": "① Paste any URL", "start": 3.0, "end": 7.0, "x": 0.5, "y": 0.88, "size": 0.034, "bg": "#111111CC"}],
  "style": {
    "background": {"type": "gradient", "colors": ["#4f46e5", "#ec4899"], "angle": 135},
    "padding": 0.06, "radius": 18,
    "shadow": {"blur": 40, "opacity": 0.45, "offset_y": 18}
  },
  "intro": {"title": "ProjectName", "subtitle": "One-line pitch", "duration": 2.5},
  "outro": {"title": "Try it", "subtitle": "github.com/user/repo", "duration": 2.5},
  "music": {"path": "bg.mp3", "volume": 0.12},
  "mute": false
}
```

- **Zoom ramp** 0.5 = snappy, 0.7 = Recordly default, 1.0 = cinematic. Camera never shows outside the frame (centre auto-clamped).
- **Background** types: `gradient` (2+ colors, any angle), `solid` (`color`), `image` (`path`, optional `blur`). Good gradients: `#4f46e5→#ec4899` (vivid), `#0f172a→#334155` (dark pro), `#f97316→#facc15` (warm), `#06b6d4→#3b82f6` (cool). Set `padding: 0, radius: 0, shadow.opacity: 0` for full-bleed.
- **Aspect ratios:** 1920×1080 (Devpost/YouTube), 1080×1920 (Reels/Shorts — use padding 0.03 and stronger zooms), 1080×1080 (LinkedIn/X), 1280×720 (small upload).
- **Speed audio:** sped-up segments are pitch-preserved and ducked to 25%; for 1× sections the original voiceover is kept in sync.
- **Music** loops under the voice; keep volume 0.08–0.15 with narration, 0.3 without.

## Extra polish (ffmpeg, after render)
- Loudness normalize voice: `ffmpeg -i demo.mp4 -c:v copy -af loudnorm=I=-16:TP=-1.5:LRA=11 demo_n.mp4`
- Burn subtitles from an .srt: `ffmpeg -i demo.mp4 -vf "subtitles=subs.srt:force_style='Fontsize=22,BorderStyle=3,Outline=1,Shadow=0,MarginV=40'" -c:a copy demo_sub.mp4`. If the `video-cleanup` skill is available, use it for noisy voice tracks first.
- Webcam bubble (separate cam file): overlay a circular-masked, scaled cam at bottom-right with `overlay=W-w-40:H-h-40` after `geq`/`alphamerge` round mask.
- Thumbnail for Devpost: grab the best zoomed frame, `ffmpeg -ss T -i demo.mp4 -frames:v 1 thumb.png`.

## Pitfalls
- Analyzer works on pixel change, not real cursor data: a moving cursor alone may trigger tiny zooms — drop zooms shorter than ~1.5 s or with no meaningful UI change.
- Scrolling and page navigations produce full-frame change → listed in `scene_changes`, not zooms. Don't hold a zoom across one.
- Very high-res sources (4K / Retina) render slowly — downscale to 1080p first: `ffmpeg -i in.mov -vf scale=-2:1080 -c:a copy in1080.mp4`.
- Variable-frame-rate phone/OBS files: if audio drifts, convert first: `ffmpeg -i in.mp4 -vf fps=30 -c:a aac cfr.mp4`.
- Overlapping `speed` regions: the first match wins; keep them non-overlapping.
- Always look at rendered frames before delivering — never deliver an unchecked render.

## The script — write this verbatim to `recordly_edit.py`

```python
#!/usr/bin/env python3
"""Recordly-style demo video editor: analyze + render.

  python3 recordly_edit.py analyze INPUT.mp4 -o plan.json   # auto-suggest zooms, speed-ups
  python3 recordly_edit.py render  INPUT.mp4 plan.json -o out.mp4 [--gif out.gif] [--preview]
  python3 recordly_edit.py sheet   INPUT.mp4 -o sheet.png --every 2   # timestamped contact sheet

All x/y coordinates are normalized to the SOURCE frame (0..1, origin top-left).
All times in the plan are SOURCE seconds.
"""
import argparse, json, math, os, subprocess, sys, tempfile
import numpy as np
import cv2

FONT_CANDIDATES = [
    "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]

DEFAULT_PLAN = {
    "output": {"width": 1920, "height": 1080, "fps": 60, "crf": 18},
    "trim": {"start": 0, "end": None},
    "style": {
        "background": {"type": "gradient", "colors": ["#4f46e5", "#ec4899"], "angle": 135},
        "padding": 0.06, "radius": 18,
        "shadow": {"blur": 40, "opacity": 0.45, "offset_y": 18},
    },
    "zoom": {"ramp": 0.7, "merge_gap": 1.2, "motion_blur": True},
    "zooms": [], "speed": [], "clicks": [], "annotations": [],
    "intro": None, "outro": None,
}

# ----------------------------------------------------------------- helpers
def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
        "stream=codec_type,width,height,r_frame_rate:format=duration", "-of", "json", path],
        capture_output=True, text=True, check=True).stdout
    j = json.loads(out)
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    n, d = v["r_frame_rate"].split("/")
    return dict(w=int(v["width"]), h=int(v["height"]), fps=float(n) / float(d),
                dur=float(j["format"]["duration"]),
                audio=any(s["codec_type"] == "audio" for s in j["streams"]))

def hex2bgr(h):
    h = h.lstrip("#"); return (int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16))

def ease(x):  # smootherstep — the soft "Apple" in/out curve
    x = min(max(x, 0.0), 1.0); return x * x * x * (x * (x * 6 - 15) + 10)

def deep_merge(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        out[k] = deep_merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out

def font(size):
    from PIL import ImageFont
    for f in FONT_CANDIDATES:
        if os.path.exists(f):
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()

# ----------------------------------------------------------------- analyze
def analyze(inp, out_path, sample_fps=6.0, zoom_scale=1.8):
    info = probe(inp)
    cap = cv2.VideoCapture(inp)
    step = max(1, round(info["fps"] / sample_fps))
    W = 320; H = int(W * info["h"] / info["w"])
    prev = None; samples = []; i = 0
    while True:
        ok, fr = cap.read()
        if not ok: break
        if i % step == 0:
            g = cv2.GaussianBlur(cv2.cvtColor(cv2.resize(fr, (W, H)), cv2.COLOR_BGR2GRAY), (5, 5), 0)
            t = i / info["fps"]
            if prev is not None:
                m = (cv2.absdiff(g, prev) > 18).astype(np.uint8)
                m = cv2.dilate(m, np.ones((7, 7), np.uint8))
                area = m.mean()
                if area > 0.0005:
                    ys, xs = np.nonzero(m)
                    x0, x1 = np.percentile(xs, [5, 95]); y0, y1 = np.percentile(ys, [5, 95])
                    samples.append(dict(t=t, area=area, cx=(x0 + x1) / 2 / W, cy=(y0 + y1) / 2 / H,
                                        bw=(x1 - x0) / W, bh=(y1 - y0) / H))
                else:
                    samples.append(dict(t=t, area=0.0))
            prev = g
        i += 1
    cap.release()

    # Local activity (small area, not a full-page change) -> zoom candidates
    zooms, cur = [], None
    for s in samples:
        local = 0.0005 < s["area"] < 0.25 and s.get("bw", 1) < 0.6 and s.get("bh", 1) < 0.6
        if local and cur and math.hypot(s["cx"] - cur["cx"], s["cy"] - cur["cy"]) < 0.18 and s["t"] - cur["last"] < 0.8:
            n = cur["n"]; cur["cx"] = (cur["cx"] * n + s["cx"]) / (n + 1); cur["cy"] = (cur["cy"] * n + s["cy"]) / (n + 1)
            cur["bw"] = max(cur["bw"], s["bw"]); cur["bh"] = max(cur["bh"], s["bh"]); cur["n"] += 1; cur["last"] = s["t"]
        elif local:
            if cur: zooms.append(cur)
            cur = dict(start=s["t"], last=s["t"], cx=s["cx"], cy=s["cy"], bw=s["bw"], bh=s["bh"], n=1)
    if cur: zooms.append(cur)
    out_z = []
    for z in zooms:
        if z["last"] - z["start"] < 0.8: continue
        fit = 0.75 / max(z["bw"], z["bh"], 1e-3)          # keep the active box ~75% of view
        sc = round(min(max(fit, 1.3), 2.5, zoom_scale + 0.7), 2)
        out_z.append(dict(start=round(max(0, z["start"] - 0.4), 2), end=round(z["last"] + 0.8, 2),
                          x=round(z["cx"], 3), y=round(z["cy"], 3), scale=sc))

    # Idle stretches -> speed-up suggestions
    speed, idle0 = [], None
    for s in samples + [dict(t=info["dur"], area=1)]:
        if s["area"] < 0.0005:
            idle0 = s["t"] if idle0 is None else idle0
        else:
            if idle0 is not None and s["t"] - idle0 >= 3.0:
                speed.append(dict(start=round(idle0 + 0.5, 2), end=round(s["t"] - 0.5, 2), rate=4.0))
            idle0 = None
    scene_changes = [round(s["t"], 2) for s in samples if s["area"] >= 0.25]

    plan = deep_merge(DEFAULT_PLAN, {})
    plan["zooms"] = out_z; plan["speed"] = speed
    plan["_analysis"] = dict(source=info, scene_changes=scene_changes,
        note="Suggestions only. Verify with contact sheets; remove zooms on scroll/page transitions.")
    with open(out_path, "w") as f: json.dump(plan, f, indent=2)
    print(f"{len(out_z)} zoom suggestions, {len(speed)} speed-up regions, {len(scene_changes)} scene changes -> {out_path}")

# ----------------------------------------------------------------- time map
def build_timemap(plan, info):
    """Return list of (src_start, src_end, rate) segments covering the trimmed range."""
    t0 = plan["trim"].get("start") or 0.0
    t1 = plan["trim"].get("end") or info["dur"]
    cuts = sorted(plan.get("cuts", []), key=lambda c: c["start"])
    sp = sorted([s for s in plan.get("speed", []) if s["end"] > s["start"]], key=lambda s: s["start"])
    pts = {t0, t1}
    for r in sp + cuts: pts |= {min(max(r["start"], t0), t1), min(max(r["end"], t0), t1)}
    pts = sorted(pts); segs = []
    for a, b in zip(pts, pts[1:]):
        if b - a < 1e-3: continue
        m = (a + b) / 2
        if any(c["start"] <= m < c["end"] for c in cuts): continue
        rate = next((s["rate"] for s in sp if s["start"] <= m < s["end"]), 1.0)
        segs.append((a, b, rate))
    return segs

def src_to_out(t, segs):
    acc = 0.0
    for a, b, r in segs:
        if t < a: return acc
        if t <= b: return acc + (t - a) / r
        acc += (b - a) / r
    return acc

# ----------------------------------------------------------------- camera
class Camera:
    """Step targets smoothed with eased transitions on the OUTPUT timeline."""
    def __init__(self, plan, segs, aspect):
        zc = plan["zoom"]; self.ramp = zc["ramp"]; self.aspect = aspect
        base = (0.5, 0.5, 1.0)
        zs = sorted(plan.get("zooms", []), key=lambda z: z["start"])
        # merge: if next zoom starts soon after previous ends, pan directly (no zoom-out)
        evs = []
        for i, z in enumerate(zs):
            tgt = (z["x"], z["y"], max(1.0, z.get("scale", 2.0)))
            evs.append((src_to_out(z["start"], segs), tgt))
            nxt = zs[i + 1] if i + 1 < len(zs) else None
            if not (nxt and nxt["start"] - z["end"] < zc["merge_gap"]):
                evs.append((src_to_out(z["end"], segs), base))
        self.evs = sorted(evs, key=lambda e: e[0])
        self.k = 0; self.frm = base; self.to = base; self.ts = -1e9; self.cur = base; self.prev = base

    def clamp(self, cx, cy, s):
        h = 0.5 / s
        return (min(max(cx, h), 1 - h), min(max(cy, h), 1 - h), s)

    def at(self, t):
        while self.k < len(self.evs) and t >= self.evs[self.k][0]:
            self.frm = self.cur; self.to = self.evs[self.k][1]; self.ts = self.evs[self.k][0]; self.k += 1
        e = ease((t - self.ts) / self.ramp)
        ls = math.log(self.frm[2]) + (math.log(self.to[2]) - math.log(self.frm[2])) * e
        s = math.exp(ls)
        # interpolate the *clamped* centres so pans never reveal outside the frame
        f = self.clamp(*self.frm); g = self.clamp(*self.to)
        cx = f[0] + (g[0] - f[0]) * e; cy = f[1] + (g[1] - f[1]) * e
        self.prev = self.cur; self.cur = self.clamp(cx, cy, s)
        return self.cur

# ----------------------------------------------------------------- styling
def make_background(st, W, H):
    bg = st["background"]
    if bg["type"] == "solid":
        return np.full((H, W, 3), hex2bgr(bg["color"]), np.uint8)
    if bg["type"] == "image":
        img = cv2.imread(bg["path"]); ih, iw = img.shape[:2]; sc = max(W / iw, H / ih)
        img = cv2.resize(img, (int(iw * sc + 1), int(ih * sc + 1)))
        y = (img.shape[0] - H) // 2; x = (img.shape[1] - W) // 2
        out = img[y:y + H, x:x + W]
        return cv2.GaussianBlur(out, (0, 0), bg.get("blur", 0)) if bg.get("blur") else out
    cols = [np.array(hex2bgr(c), np.float32) for c in bg["colors"]]
    a = math.radians(bg.get("angle", 135))
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    p = (xx / W - 0.5) * math.sin(a) - (yy / H - 0.5) * math.cos(a)
    p = (p - p.min()) / (p.max() - p.min())
    n = len(cols) - 1; idx = np.minimum((p * n).astype(int), n - 1); f = (p * n - idx)[..., None]
    c0 = np.stack(cols)[idx]; c1 = np.stack(cols)[idx + 1]
    out = c0 * (1 - f) + c1 * f
    out += np.random.default_rng(0).normal(0, 1.2, out.shape)  # dither: no banding
    return np.clip(out, 0, 255).astype(np.uint8)

def rounded_mask(w, h, r):
    m = np.zeros((h, w), np.uint8); r = int(min(r, w // 2, h // 2))
    cv2.rectangle(m, (r, 0), (w - r, h), 255, -1); cv2.rectangle(m, (0, r), (w, h - r), 255, -1)
    for cx, cy in [(r, r), (w - r - 1, r), (r, h - r - 1), (w - r - 1, h - r - 1)]:
        cv2.circle(m, (cx, cy), r, 255, -1, cv2.LINE_AA)
    return m

def build_stage(plan, info):
    o = plan["output"]; st = plan["style"]; W, H = o["width"], o["height"]
    bg = make_background(st, W, H).astype(np.float32); plain = bg.copy()
    pad = st["padding"]; aw = W * (1 - 2 * pad); ah = H * (1 - 2 * pad)
    src_ar = info["w"] / info["h"]
    if aw / ah > src_ar: ih = int(ah); iw = int(ih * src_ar)
    else: iw = int(aw); ih = int(iw / src_ar)
    iw -= iw % 2; ih -= ih % 2
    x0 = (W - iw) // 2; y0 = (H - ih) // 2
    mask = rounded_mask(iw, ih, st["radius"]).astype(np.float32) / 255.0
    sh = st.get("shadow")
    if sh and sh.get("opacity", 0) > 0:
        full = np.zeros((H, W), np.float32)
        oy = int(sh.get("offset_y", 0)); full[y0 + oy:y0 + oy + ih, x0:x0 + iw] = mask[:max(0, min(ih, H - y0 - oy))]
        full = cv2.GaussianBlur(full, (0, 0), sh.get("blur", 40) / 2) * sh["opacity"]
        bg *= (1 - full[..., None])
    return dict(bg=bg, plain=plain, x0=x0, y0=y0, iw=iw, ih=ih, mask=mask[..., None])

# ----------------------------------------------------------------- overlays
def draw_clicks(inner, t_src, cam, plan, iw, ih):
    for c in plan.get("clicks", []):
        dt = t_src - c["t"]
        if not (0 <= dt <= 0.6): continue
        cx, cy, s = cam
        px = ((c["x"] - cx) * s + 0.5) * iw; py = ((c["y"] - cy) * s + 0.5) * ih
        p = dt / 0.6; r = int((10 + 34 * ease(p)) * iw / 1600 * max(1, s * 0.8))
        ov = inner.copy()
        cv2.circle(ov, (int(px), int(py)), r, c.get("color_bgr", (255, 255, 255)), max(2, iw // 500), cv2.LINE_AA)
        cv2.circle(ov, (int(px), int(py)), max(3, r // 4), (255, 255, 255), -1, cv2.LINE_AA)
        a = 0.85 * (1 - p); cv2.addWeighted(ov, a, inner, 1 - a, 0, inner)

def text_card(W, H, title, subtitle, bg):
    from PIL import Image, ImageDraw
    img = Image.fromarray(cv2.cvtColor(np.clip(bg, 0, 255).astype(np.uint8), cv2.COLOR_BGR2RGB))
    d = ImageDraw.Draw(img); f1 = font(int(H * 0.085)); f2 = font(int(H * 0.035))
    for txt, f, yy in [(title, f1, 0.44), (subtitle, f2, 0.58)]:
        if not txt: continue
        b = d.textbbox((0, 0), txt, font=f); tw = b[2] - b[0]
        d.text(((W - tw) / 2, H * yy - (b[3] - b[1]) / 2), txt, font=f, fill=(255, 255, 255))
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

def annotation_layer(a, W, H):
    """Pre-render a pill callout (RGBA)."""
    from PIL import Image, ImageDraw
    f = font(int(H * a.get("size", 0.034)))
    tmp = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    b = tmp.textbbox((0, 0), a["text"], font=f); tw, th = b[2] - b[0], b[3] - b[1]
    px, py = int(th * 0.9), int(th * 0.6)
    img = Image.new("RGBA", (tw + 2 * px, th + 2 * py), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, img.width - 1, img.height - 1], radius=img.height // 2,
                        fill=tuple(int(a.get("bg", "#111111CC").lstrip("#")[i:i + 2], 16) for i in (0, 2, 4, 6)))
    d.text((px, py - b[1]), a["text"], font=f, fill=(255, 255, 255, 255))
    arr = np.array(img).astype(np.float32)
    return arr[..., [2, 1, 0]], arr[..., 3:4] / 255.0

def paste(frame, rgb, alpha, x, y, k):
    h, w = rgb.shape[:2]; H, W = frame.shape[:2]
    x = int(min(max(x, 0), W - w)); y = int(min(max(y, 0), H - h))
    roi = frame[y:y + h, x:x + w]; a = alpha * k
    frame[y:y + h, x:x + w] = roi * (1 - a) + rgb * a

# ----------------------------------------------------------------- render
def render(inp, plan_path, out, gif=None, preview=False):
    info = probe(inp)
    plan = deep_merge(DEFAULT_PLAN, json.load(open(plan_path)))
    if preview:
        o_ = plan["output"]; o_.update(width=o_["width"] // 4 * 2, height=o_["height"] // 4 * 2, fps=30)
    o = plan["output"]; W, H, FPS = o["width"], o["height"], o["fps"]
    segs = build_timemap(plan, info)
    total = sum((b - a) / r for a, b, r in segs)
    stage = build_stage(plan, info); iw, ih, x0, y0 = stage["iw"], stage["ih"], stage["x0"], stage["y0"]
    cam = Camera(plan, segs, info["w"] / info["h"])
    anns = [(a, *annotation_layer(a, W, H)) for a in plan.get("annotations", [])]
    tmpd = tempfile.mkdtemp(); vid = os.path.join(tmpd, "v.mp4")

    enc = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgr24",
        "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "veryfast",
        "-crf", str(o["crf"]), "-pix_fmt", "yuv420p", vid], stdin=subprocess.PIPE)

    def card_frames(spec):
        if not spec: return 0
        card = text_card(W, H, spec.get("title", ""), spec.get("subtitle", ""), stage["plain"])
        n = int(spec.get("duration", 2.0) * FPS)
        for i in range(n):
            k = min(1, i / (0.4 * FPS), (n - i) / (0.4 * FPS))
            enc.stdin.write((card * k).astype(np.uint8).tobytes())
        return n / FPS

    intro_d = card_frames(plan.get("intro"))
    cap = cv2.VideoCapture(inp); cap_t = -1; frame = None
    nframes = int(total * FPS)
    for fi in range(nframes):
        to = fi / FPS
        acc = 0.0; ts = segs[-1][1]
        for a, b, r in segs:
            d = (b - a) / r
            if to < acc + d: ts = a + (to - acc) * r; break
            acc += d
        # read forward to ts (seek only if jumping far back/forward)
        if frame is None or ts < cap_t or ts - cap_t > 2.0:
            cap.set(cv2.CAP_PROP_POS_MSEC, ts * 1000); ok, frame = cap.read()
            cap_t = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000
        while cap_t + 1 / info["fps"] <= ts:
            ok, nf = cap.read()
            if not ok: break
            frame = nf; cap_t = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000
        cx, cy, s = cam.at(to)
        # crop window in source px -> inner size, via one affine warp (sub-pixel smooth)
        sx = iw * s / info["w"]; sy = ih * s / info["h"]
        M = np.float32([[sx, 0, iw / 2 - cx * info["w"] * sx], [0, sy, ih / 2 - cy * info["h"] * sy]])
        inner = cv2.warpAffine(frame, M, (iw, ih), flags=cv2.INTER_CUBIC if s > 1.01 else cv2.INTER_AREA,
                               borderMode=cv2.BORDER_REPLICATE)
        if plan["zoom"].get("motion_blur"):
            p = cam.prev; vel = abs(math.log(s) - math.log(p[2])) + math.hypot(cx - p[0], cy - p[1]) * s
            if vel > 0.004:  # average sub-frames between previous and current camera = real motion blur
                n = int(min(6, 2 + vel * 150)); acc_f = inner.astype(np.float32)
                for j in range(1, n):
                    f_ = j / n; qs = math.exp(math.log(s) + (math.log(p[2]) - math.log(s)) * f_)
                    qx = cx + (p[0] - cx) * f_; qy = cy + (p[1] - cy) * f_
                    a_, b_ = iw * qs / info["w"], ih * qs / info["h"]
                    Mq = np.float32([[a_, 0, iw / 2 - qx * info["w"] * a_], [0, b_, ih / 2 - qy * info["h"] * b_]])
                    acc_f += cv2.warpAffine(frame, Mq, (iw, ih), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
                inner = (acc_f / n).astype(np.uint8)
        draw_clicks(inner, ts, (cx, cy, s), plan, iw, ih)
        out_f = stage["bg"].copy()
        roi = out_f[y0:y0 + ih, x0:x0 + iw]
        out_f[y0:y0 + ih, x0:x0 + iw] = roi * (1 - stage["mask"]) + inner.astype(np.float32) * stage["mask"]
        for a, rgb, al in anns:
            if a["start"] <= ts <= a["end"]:
                k = min(1, (ts - a["start"]) / 0.3, (a["end"] - ts) / 0.3)
                hgt, wid = rgb.shape[:2]
                px = a.get("x", 0.5) * W - wid / 2; py = a.get("y", 0.88) * H - hgt / 2
                paste(out_f, rgb, al, px, py - (1 - ease(k)) * 12, k)
        enc.stdin.write(out_f.astype(np.uint8).tobytes())
        if fi % (FPS * 5) == 0: print(f"  {to:6.1f}s / {total:.1f}s", file=sys.stderr)
    outro_d = card_frames(plan.get("outro"))
    enc.stdin.close(); enc.wait(); cap.release()

    # audio: same time map (atrim + atempo per segment), padded for cards
    if info["audio"] and not plan.get("mute"):
        fc, labels = [], []
        for i, (a, b, r) in enumerate(segs):
            chain = f"[0:a]atrim={a:.4f}:{b:.4f},asetpts=PTS-STARTPTS"
            rr = r
            while rr > 2.0: chain += ",atempo=2.0"; rr /= 2.0
            while rr < 0.5: chain += ",atempo=0.5"; rr /= 0.5
            if abs(rr - 1) > 1e-3: chain += f",atempo={rr:.4f}"
            if r > 1.5: chain += ",volume=0.25"   # duck sped-up audio
            fc.append(chain + f"[a{i}]"); labels.append(f"[a{i}]")
        fc.append("".join(labels) + f"concat=n={len(segs)}:v=0:a=1[ac]")
        fc.append(f"[ac]adelay={int(intro_d * 1000)}:all=1,apad[aout]")
        music = plan.get("music")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", inp, "-i", vid]
        if music:
            cmd += ["-stream_loop", "-1", "-i", music["path"]]
            fc[-1] = f"[ac]adelay={int(intro_d * 1000)}:all=1,apad[voice]"
            fc.append(f"[2:a]volume={music.get('volume', 0.15)}[m]")
            fc.append("[voice][m]amix=inputs=2:duration=first:normalize=0[aout]")
        cmd += ["-filter_complex", ";".join(fc), "-map", "1:v", "-map", "[aout]",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out]
        subprocess.run(cmd, check=True)
    else:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", vid, "-c", "copy", "-movflags", "+faststart", out], check=True)
    print(f"wrote {out}  ({intro_d + total + outro_d:.1f}s)")
    if gif:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", out, "-vf",
            "fps=15,scale=960:-1:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=sierra2_4a",
            "-loop", "0", gif], check=True)
        print(f"wrote {gif}")

def contact_sheet(inp, out_png, every=2.0, cols=6):
    """Grid of timestamped thumbnails so Claude can SEE the video and pick zoom targets."""
    info = probe(inp); cap = cv2.VideoCapture(inp); tiles = []; t = 0.0
    tw = 480; th = int(tw * info["h"] / info["w"])
    while t < info["dur"]:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000); ok, fr = cap.read()
        if not ok: break
        fr = cv2.resize(fr, (tw, th))
        for gx in range(1, 10):  # 10% grid to read off normalized x/y
            cv2.line(fr, (tw * gx // 10, 0), (tw * gx // 10, th), (0, 255, 255), 1)
            cv2.line(fr, (0, th * gx // 10), (tw, th * gx // 10), (0, 255, 255), 1)
        cv2.rectangle(fr, (0, 0), (110, 30), (0, 0, 0), -1)
        cv2.putText(fr, f"{t:.1f}s", (6, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        tiles.append(fr); t += every
    while len(tiles) % cols: tiles.append(np.zeros_like(tiles[0]))
    rows = [np.hstack(tiles[i:i + cols]) for i in range(0, len(tiles), cols)]
    cv2.imwrite(out_png, np.vstack(rows)); print(f"wrote {out_png} ({len(tiles)} tiles)")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze"); a.add_argument("input"); a.add_argument("-o", default="plan.json")
    r = sub.add_parser("render"); r.add_argument("input"); r.add_argument("plan"); r.add_argument("-o", default="demo.mp4")
    r.add_argument("--gif"); r.add_argument("--preview", action="store_true")
    c = sub.add_parser("sheet"); c.add_argument("input"); c.add_argument("-o", default="sheet.png")
    c.add_argument("--every", type=float, default=2.0)
    x = ap.parse_args()
    if x.cmd == "analyze": analyze(x.input, x.o)
    elif x.cmd == "render": render(x.input, x.plan, x.o, x.gif, x.preview)
    else: contact_sheet(x.input, x.o, x.every)
```